﻿using System;
using System.Threading.Tasks;
using Kitverse_backend_01.Models;
using static Kitverse_backend_01.Services.PasswordHasher; // importing the static class PasswordHasher to use the HashPassword method without creating an instance of the class.


namespace Kitverse_backend_01.Controllers
{
    public class AuthService : IAuthService // this class is used to implement the methods defined in the IAuthService interface.
    {

        public async Task<User> Register(User user)
        {
            if (string.IsNullOrWhiteSpace(user.UserName) || 
                string.IsNullOrWhiteSpace(user.userEmail) ||
                string.IsNullOrWhiteSpace(user.userPassword)) // checking if username, email and password are not null or empty
            {
                throw new ArgumentException("Username, email and password are required.");
            }
            try
            {
                var uexistingUser = await GetByEmail(user.userEmail); // U songo hangwa u connect na database.

                if (uexistingUser != null)
                {
                    throw new InvalidOperationException("User with this email already exists.");
                }
                else
                {
                    user.userPassword = HashPassword(user.userPassword); // hashing the password before saving it to the database.
                 // Save the user to the database here (this part is not implemented yet).
                  
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException("An error occurred while registering the user: " + ex.Message);

            }
            return user;
        }

        public async Task<int> Login(string username, string password)
        {
            try
            {
                var isLoggedIn = await VerifyPassword(username, password); // U songo hangwa u connect na database.
                if(isLoggedIn!=null)
                {
                    return 1; // user signed in successfully
                } 
                return 0; // user failed to sign in


            }
            catch (Exception ex)
            {
                throw new ArgumentException("An error occurred while logging in: " + ex.Message);
            }
        }

        // a songo hangwa u connect na database
        //then a remove hedzi helper method .
        private async void GetByEmail(string email)
        {
            
        }
        private int VerifyPassword(string username, string password) {
            return 1;
        }

    }
}
