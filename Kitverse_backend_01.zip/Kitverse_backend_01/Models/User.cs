﻿namespace Kitverse_backend_01.Models
{
    public class User
    {
        public int UserId { get; set; } // user id

        public string UserName { get; set; } // user name

        public string userEmail { get; set; } // user email

        public string userPassword { get; set; } // user password

        public string userRole { get; set; } // user role

    }
}
